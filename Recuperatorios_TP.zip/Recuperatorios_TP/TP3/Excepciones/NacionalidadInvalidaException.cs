﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    public class NacionalidadInvalidaException : Exception
    {
        public NacionalidadInvalidaException()
        : base() { }

        public NacionalidadInvalidaException(string message)
        : base(message) { }

        public NacionalidadInvalidaException(string format, params object[] args)
        : base(string.Format(format, args)) { }

        public NacionalidadInvalidaException(string message, Exception innerException)
        : base(message, innerException) { }

        public NacionalidadInvalidaException(string format, Exception innerException, params object[] args)
        : base(string.Format(format, args), innerException) { }

        protected NacionalidadInvalidaException(SerializationInfo info, StreamingContext context)
        : base(info, context) { }

    }
    }
