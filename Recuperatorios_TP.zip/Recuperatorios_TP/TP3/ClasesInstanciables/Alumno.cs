﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
using Clases_Abstractas;

namespace ClasesInstanciables
{
    public sealed class Alumno : Universitario
    {

        public enum EEstadoCuenta
        {
            Becado, Deudor, AlDia
        }

        private Universidad.EClases _claseQueToma;
        private EEstadoCuenta _estadoCuenta;


        public Alumno() : base()
        {
            this._claseQueToma = Universidad.EClases.Laboratorio;
            this._estadoCuenta = EEstadoCuenta.AlDia;
        }
        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma) : base(id, nombre, apellido, dni, nacionalidad)
        {
            this._claseQueToma = claseQueToma;
        }
        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma, EEstadoCuenta estadoCuenta) : this(id, nombre, apellido, dni, nacionalidad, claseQueToma)
        {
            this._estadoCuenta = estadoCuenta;
        }


        /// <summary>
        /// retorna la clase que toma el alumno
        /// </summary>
        /// <returns>clase que toma el alumno</returns>
        protected override string ParticiparEnClase()
        {
            return "Toma  clase de: " + this._claseQueToma;
        }


        /// <summary>
        /// Retorna  los datos del Alumno
        /// </summary>
        /// <returns>Datos del alumno</returns>
        protected override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.MostrarDatos());
            sb.AppendLine("Estado de cuenta: " + this._estadoCuenta);
            sb.AppendLine(this.ParticiparEnClase());

            return sb.ToString();
        }

      


        /// <summary>
        /// Retorna  los datos del Alumno
        /// </summary>
        /// <returns>Datos del alumno</returns>
        public override string ToString()
        {
            return this.MostrarDatos();
        }


        public static bool operator ==(Alumno alumno, Universidad.EClases clase)
        {
            return (alumno._claseQueToma == clase && alumno._estadoCuenta != EEstadoCuenta.Deudor);
        }

        public static bool operator !=(Alumno alumno, Universidad.EClases clase)
        {
            return !(alumno == clase);
        }
    }
}
