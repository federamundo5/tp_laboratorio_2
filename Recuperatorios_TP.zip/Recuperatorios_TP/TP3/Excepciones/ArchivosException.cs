﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
   public class ArchivosException:Exception
    {
        static string mensaje = "Error al escribir o leer el archivo";

        public ArchivosException():base()
        {
        }
        public ArchivosException(Exception e):base()
        {
            mensaje = e.Message;
        }
        public ArchivosException(string message):base(message)
        {
        }
        public ArchivosException(string message, Exception e):base(mensaje,e)
        {
        }
    }
}
