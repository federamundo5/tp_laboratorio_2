﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Archivos;
using Excepciones;

namespace ClasesInstanciables
{
  public class Jornada
    {
        protected List<Alumno> _alumnos;
        protected Profesor _instructor;
        protected Universidad.EClases _clase;


        private Jornada()
        {
            this._alumnos = new List<Alumno>();
        }
        public Jornada(Universidad.EClases clase, Profesor instructor) : this()
        {
            this._instructor = instructor;
            this._clase = clase;
        }

        //propiedades
        public Universidad.EClases Clase  { get { return this._clase; }  set { this._clase = value; }}
        public List<Alumno> Alumnos { get { return this._alumnos; }    set { this._alumnos = value; }}
        public Profesor Instructor {get { return this._instructor;}    set { this._instructor = value;}  }



        public static bool operator ==(Jornada j, Alumno a)
        {
            return (a == j._clase);
        }
        public static bool operator !=(Jornada j, Alumno a)
        {
            return !(j == a);
        }

        public static Jornada operator +(Jornada j, Alumno a)
        {
            foreach(Alumno alumno in j.Alumnos)
            {
                if (alumno == a)
                    return j;
            }
       
            j._alumnos.Add(a);

            return j;
        }



        /// <summary>
        /// retorna datos jornadas
        /// </summary>
        /// <returns>string con los datos de la jornada</returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Jornada:");
            sb.AppendFormat("Clase  de: {0} por ", _clase.ToString());
            sb.Append(_instructor.ToString());
            sb.AppendLine("Alumnos:");
            foreach (Alumno a in this._alumnos)
            {
                sb.Append(a.ToString());
            }
            sb.AppendLine("<----------------------------------------------->");
            return sb.ToString();
        }
        /// <summary>
        ///guarda la jornada en un archivo texto
        /// </summary>
        /// <param name="jornada"></param>
        /// <returns>true si guardo, o excepcion</returns>
        public static bool Guardar(Jornada jornada)
        {
            Texto archivo = new Texto();
            archivo.guardar(AppDomain.CurrentDomain.BaseDirectory + "Jornada.txt", jornada.ToString());
            return true;
        }
        /// <summary>
        /// returna texto del archivo txt
        /// </summary>
        /// <returns>texto del archivo</returns>
        public static string Leer()
        {
            string texto = "";
            Texto archivo = new Texto();
            archivo.leer(AppDomain.CurrentDomain.BaseDirectory + "Jornada.txt", out texto);
            return texto;

        }

    }
}
