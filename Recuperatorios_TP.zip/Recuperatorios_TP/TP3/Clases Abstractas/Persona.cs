﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;

namespace Clases_Abstractas
{
    public abstract class Persona
    {


        public enum ENacionalidad
        {
            Argentino, Extranjero
        }

        string _apellido;
        int _dni;
        ENacionalidad _nacionalidad;
        string _nombre;


        public Persona()
        {
            this._nombre = "";
            this._apellido = "";
            this._dni = 0;
            this._nacionalidad = ENacionalidad.Argentino;
        }


        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Nacionalidad = nacionalidad;
        }

        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad):this(nombre,apellido,nacionalidad)
        {
            this.DNI = dni;
        }

        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        {
            this.StringToDNI = dni;
        }


        public string Apellido
        {
            set { this._apellido = ValidarNombreApellido(value); }
            get { return this._apellido; }
         
        }

        public string Nombre
        {
            set { this._nombre = ValidarNombreApellido(value); }
            get { return this._nombre; }

        }

        public int DNI
        {
            set { this._dni = this.ValidarDni(this._nacionalidad,value); }
            get { return this._dni; }

        }

        public string StringToDNI
        {
            set
            {
                this._dni = this.ValidarDni(this._nacionalidad, value);
            }
        }


        public ENacionalidad Nacionalidad { set { this._nacionalidad = value; } get { return this._nacionalidad; } }


        /// <summary>
        /// Valida que el string no tenga numeros
        /// </summary>
        /// <param name="dato">Dato a verificar</param>
        /// <returns>Devuelve el string si es correcto o  tira excepcion</returns>
        private string ValidarNombreApellido(string nombre)
        {
            for (int i = 0; i < nombre.Length; i++)
            {
                if (char.IsNumber(nombre, i))
                    throw new Exception("Dato Invalido");
            }
            return nombre;
        }



        /// <summary>
        /// Verifica si el DNI es correcto
        /// </summary>
        /// <param name="nacionalidad"></param>
        /// <param name="dato"></param>
        /// <returns>Devuelvel dni si la validacion es existosa, o tira excepcion</returns>
        private int ValidarDni(ENacionalidad nacionalidad, string dni)
        {
            int retorno;

            if (!int.TryParse(dni, out retorno))
            {
                throw new DNIInvalidoException("El DNI  es incorrecto");
            }


            if (nacionalidad == ENacionalidad.Argentino)
            {

                if (retorno < 1 || retorno > 89999999)
                {
                    throw new DNIInvalidoException("El DNI  es incorrecto");
                }
            }

            if (nacionalidad == ENacionalidad.Extranjero)
            {
                if (retorno < 89999999)
                {
                    throw new NacionalidadInvalidaException("El DNI Es incorrecto");
                }
            }
            return retorno;
        }


        /// <summary>
        /// Verifica si el DNI ingresa es valido 
        /// </summary>
        /// <param name="nacionalidad"></param>
        /// <param name="dni"></param>
        /// <returns></returns>
        private int ValidarDni(ENacionalidad nacionalidad, int dni)
        {
            return this.ValidarDni(nacionalidad, dni.ToString());
        }


        /// <summary>
        /// retorna datos persona
        /// </summary>
        /// <returns>retorna datos persona</returns>
        public override string ToString()
        {
            return "Nombre Completo: " + this._apellido + "," + this._nombre + "\n Nacionalidad: " + this._nacionalidad + "\n";
        }
    }


 }

