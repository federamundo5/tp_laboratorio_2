﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClasesInstanciables;
using Clases_Abstractas;
using Excepciones;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void AlumnoRepetido()
        {
            Universidad uni = new Universidad();
            Alumno a1 = new Alumno(1, "Juan", "Lopez", "12234456",
       Persona.ENacionalidad.Argentino, Universidad.EClases.Programacion,
       Alumno.EEstadoCuenta.Becado);
            Alumno a2 = new Alumno(1, "Juan", "Lopez", "12234456",
       Persona.ENacionalidad.Argentino, Universidad.EClases.Programacion,
       Alumno.EEstadoCuenta.Becado);

            try
            {
                uni += a1;
                uni += a2;
            }
            catch (AlumnoRepetidoException ex)
            {
                Assert.IsInstanceOfType(ex, typeof(AlumnoRepetidoException));
         
            }
        }


        [TestMethod]
        public void DniInvalido()
        {
            try
            {
                Alumno a1 = new Alumno(1, "Juan", "Lopez", "DADSAdA",
            Persona.ENacionalidad.Argentino, Universidad.EClases.Programacion,
            Alumno.EEstadoCuenta.Becado);
            }
            catch (DNIInvalidoException e)
            {
                Assert.IsInstanceOfType(e, typeof(DNIInvalidoException));
            }
        }

        [TestMethod]
        public void apellidoNulo()
        {
            Alumno a1 = new Alumno(1, "Juan", "Lopez", "12234456",
              Persona.ENacionalidad.Argentino, Universidad.EClases.Programacion,
              Alumno.EEstadoCuenta.Becado);
            Assert.IsNotNull (a1.Apellido);
        }

        [TestMethod]
        public void ValorNumerico()
        {     
           if (5+6== 3+7)
            {
                Assert.Fail();
            }
        }




    }
}
