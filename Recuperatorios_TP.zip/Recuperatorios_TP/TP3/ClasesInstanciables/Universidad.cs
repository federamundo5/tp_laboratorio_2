﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
using Archivos;

namespace ClasesInstanciables
{
    public class Universidad
    {
        public enum EClases
        {
            Laboratorio, Programacion, Legislacion, SPD
        }

        private List<Alumno> _alumnos;
        private List<Profesor> _profesores;
        private List<Jornada> _jornadas;


        //propiedades
        public List<Alumno> Alumnos { get { return this._alumnos; } set { this._alumnos = value; } }
        public List<Profesor> Instructores { get { return this._profesores; } set { this._profesores = value; } }
        public List<Jornada> Jornadas { get { return this._jornadas; } set { this._jornadas = value; } }
        public Jornada this[int i] { get { return this._jornadas[i]; } set { this._jornadas[i] = value; } }


        public Universidad()
        {
            this._alumnos = new List<Alumno>();
            this._profesores = new List<Profesor>();
            this._jornadas = new List<Jornada>();
        }



        public static bool operator ==(Universidad g, Alumno a)
        {
            foreach (Alumno alumno in g._alumnos)
            {
                if (alumno == a)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(Universidad g, Alumno a)
        {
            return !(g == a);
        }

        public static bool operator ==(Universidad g, Profesor i)
        {

            foreach (Profesor prof in g._profesores)
            {
                if (prof == i)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(Universidad g, Profesor i)
        {
            return !(g == i);
        }

        public static Profesor operator ==(Universidad g, EClases clase)
        {
            foreach (Profesor t in g._profesores)
            {
                if (t == clase)
                {
                    if (!Object.Equals(t, null))
                        return t;
                }
            }
            throw new SinProfesorException();
        }


        public static Profesor operator !=(Universidad g, EClases clase)
        {
            foreach (Profesor instructor in g._profesores)
            {
                if (instructor != clase)
                    return instructor;
            }
            throw new SinProfesorException();
        }

        public static Universidad operator +(Universidad g, Profesor i)
        {
            if (g != i)
                g._profesores.Add(i);

            return g;
        }

        public static Universidad operator +(Universidad g, Alumno a)
        {
            if (g != a)
                g._alumnos.Add(a);
            else
               throw new AlumnoRepetidoException();
            return g;
        }


        public static Universidad operator +(Universidad g, EClases clase)
        {
            Jornada jornada = new Jornada(clase, g == clase);
            foreach (Alumno alumno in g._alumnos)
            {
                if (alumno == clase)
                {
                    jornada.Alumnos.Add(alumno);
                }
            }
            g._jornadas.Add(jornada);

            return g;
        }


        /// <summary>
        /// Se encarga de construir una cadena con todos los datos de la universidad, jornadas,profesores,alumnos.
        /// </summary>
        /// <param name="gim"></param>
        /// <returns>String con toda la informacion a la universidad</returns>
        private static string MostrarDatos(Universidad gim)
        {
            StringBuilder sb = new StringBuilder();
            foreach (Jornada j in gim.Jornadas)
            {
                sb.Append(j.ToString());
            }
            return sb.ToString();
        }
        /// <summary>
        ///  Se encarga de procesar y devolver los datos asociados a la universidad, jornadas,profesores,alumnos.
        /// </summary>
        /// <returns>String con toda la informacion a la universidad</returns>
        public override string ToString()
        {
            return Universidad.MostrarDatos(this);
        }


        public static bool Guardar(Universidad g)
        {
            Xml<Universidad> xml = new Xml<Universidad>();
            return xml.guardar(AppDomain.CurrentDomain.BaseDirectory + "Universidad.xml", g);
        }
        /// <summary>
        /// Se encarga de buscar el archivo xml necesario para transformarlo en un objeto y poder volcarlo al programa.
        /// </summary>
        /// <returns>un obj Universidad en caso de éxito, sinó se lanzará una excepción.</returns>
        public static Universidad Leer()
        {
            Universidad g;
            Xml<Universidad> xml = new Xml<Universidad>();
            xml.leer(AppDomain.CurrentDomain.BaseDirectory + "Universidad.xml", out g);
            return g;
        }

    
}
}
