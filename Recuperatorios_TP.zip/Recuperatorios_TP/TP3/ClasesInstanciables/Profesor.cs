﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
using Clases_Abstractas;

namespace ClasesInstanciables
{
    public sealed class Profesor : Universitario
    {
        private Queue<Universidad.EClases> _clasesDelDia;
        private static Random _random;
    
        static Profesor()
        {
            Profesor._random = new Random();
        }
        private Profesor() : base()
        {
        }

        public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad) : base(id, nombre, apellido, dni, nacionalidad)
        {
            this._clasesDelDia = new Queue<Universidad.EClases>();
            randomClases();
        }

       /// <summary>
       /// agrega 2  clases randoms a clasesdeldia.
       /// </summary>
        private void randomClases()
        {
            this._clasesDelDia.Enqueue((Universidad.EClases)Profesor._random.Next(3));
            this._clasesDelDia.Enqueue((Universidad.EClases)Profesor._random.Next(3));
        }


        protected override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.MostrarDatos());
            sb.AppendLine(this.ParticiparEnClase());
            return sb.ToString();
        }

        /// <summary>
        /// retorna string con datos de las clases del profesor
        /// </summary>
        /// <returns>String las clases en las que participa el profesor</returns>
        protected override string ParticiparEnClase()
        {
            StringBuilder sb = new StringBuilder();
            foreach (Universidad.EClases clase in this._clasesDelDia)
            {
                sb.Append(clase.ToString()+" ");
            }
            return "Clases del dia: " + sb.ToString() + "\n";
        }




        /// <summary>
        /// Retorna datos del profesor
        /// </summary>
        /// <returns>String con datos del profesorr</returns>
        public override string ToString()
        {
            return this.MostrarDatos();
        }


         
        public static bool operator == (Profesor i, Universidad.EClases clase)
        {
            if (i._clasesDelDia.Contains(clase))
                {
                    return true;
                }
            
            return false;
        }

        public static bool operator != (Profesor i, Universidad.EClases clase)
        {
            return !(i == clase);
        }

    }
}
